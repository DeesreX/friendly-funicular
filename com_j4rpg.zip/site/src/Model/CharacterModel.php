<?php
defined('_JEXEC') or die;

use Joomla\CMS\MVC\Model\;

class RpgcharactersModelCharacters extends BaseDatabaseModel
{
  public function getCharacters()
  {
    $db = $this->getDbo();
    $query = $db->getQuery(true)
      ->select('*')
      ->from('rpgcharacter');
    $db->setQuery($query);
    return $db->loadObjectList();
  }
}
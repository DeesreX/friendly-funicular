<?php
namespace Rextopia\Component\Rpgcharacter\Site\View\;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

class HtmlView extends BaseHtmlView
{
  public function display($tpl = null)
  {
    $this->characters = $this->get('Characters');
    parent::display($tpl);
  }
}
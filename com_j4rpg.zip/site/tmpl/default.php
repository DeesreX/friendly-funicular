<?php
defined('_JEXEC') or die;

foreach ($this->characters as $character) {
  echo '<div>';
  echo '<h2>' . $character->name . '</h2>';
  echo '<p>' . $character->description . '</p>';
  echo '</div>';
}